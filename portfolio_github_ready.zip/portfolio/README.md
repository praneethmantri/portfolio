# Mantri Praneeth - Personal Portfolio Website

A clean, modern, responsive personal portfolio website built with **React**, **Vite**, and **Tailwind CSS**. Designed specifically for internship and early-career software engineering applications.

## 🚀 Live Local Preview
The development server runs locally at:
```bash
http://127.0.0.1:5173/
```

## 🛠️ Tech Stack & Architecture
- **Framework:** React 19 + Vite 8
- **Styling:** Tailwind CSS v4
- **Icons:** Lucide React + custom SVG icons
- **Data Architecture:** Single centralized configuration file at [`src/data/portfolioData.js`](src/data/portfolioData.js)

## 📁 Project Structure
```
protfolio/
├── public/
│   └── favicon.svg              # Custom MP monogram SVG favicon
├── src/
│   ├── components/
│   │   ├── Navbar.jsx           # Sticky nav with mobile drawer & active section spy
│   │   ├── Hero.jsx             # Hero section with MP monogram badge & CTAs
│   │   ├── About.jsx            # Natural student background & academic highlights
│   │   ├── Skills.jsx           # Categorized skill badges (no percentage bars)
│   │   ├── Projects.jsx         # AI Battery Health & Online Assessment System cards
│   │   ├── ProjectModal.jsx     # Detailed project architecture & highlight modal
│   │   ├── Contact.jsx          # One-click copy email, LinkedIn & inquiry form
│   │   ├── Footer.jsx           # Clean footer without AI watermarks
│   │   └── Icons.jsx            # Standalone accessible SVG icons
│   ├── data/
│   │   └── portfolioData.js     # Single easy-to-edit data file
│   ├── App.jsx                  # Main page layout with accessibility skip link
│   ├── index.css                # Base Tailwind styles & accessibility focus rings
│   └── main.jsx                 # React root mount
├── package.json
└── vite.config.js               # Vite + React + Tailwind v4 plugin config
```

## ✏️ How to Edit Content
All portfolio content (name, links, bio, skills, project descriptions, contact details) is centralized in:
👉 [`src/data/portfolioData.js`](src/data/portfolioData.js)

To update any text or add new projects, simply open this file and edit the fields.

## 💻 Available Commands
- `npm run dev` - Start local development server
- `npm run build` - Create optimized production build (`dist/`)
- `npm run lint` - Run code quality and linting checks
- `npm run preview` - Preview production build locally

## GitHub Pages deployment

The workflow in `.github/workflows/deploy.yml` installs dependencies, checks the
source, builds the portfolio, and publishes it on every push to `main`. It also
supports manual runs from the Actions tab.

For the first deployment, select **Settings → Pages → Source → GitHub Actions**
in the repository. The workflow uses the configured Pages base path so assets
work both at an account's root URL and under a repository URL.

Use Node.js 24 and run `npm ci` before starting local development. Edit the
source files and commit them; `node_modules` and generated `dist` output are
excluded from Git.

The contact form opens the visitor's email application using `mailto:`. It does
not require a server or collect messages in a backend.
