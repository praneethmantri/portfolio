import React, { useState } from 'react';
import { 
  FolderGit2, 
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  Activity, 
  FileCheck 
  , Sprout
  , Atom
} from 'lucide-react';
import { portfolioData } from '../data/portfolioData';
import ProjectModal from './ProjectModal';

export default function Projects() {
  const { projects } = portfolioData;
  const [selectedProject, setSelectedProject] = useState(null);

  const getProjectIcon = (id) => {
    switch (id) {
      case 'ai-battery-health':
        return <Activity className="w-5 h-5 text-sky-400" />;
      case 'online-assessment-system':
        return <FileCheck className="w-5 h-5 text-sky-400" />;
      case 'kisaan-saathi':
        return <Sprout className="w-5 h-5 text-sky-400" />;
      case 'qlassify':
        return <Atom className="w-5 h-5 text-sky-400" />;
      default:
        return <Layers className="w-5 h-5 text-sky-400" />;
    }
  };

  return (
    <section
      id="projects"
      className="py-20 sm:py-28 relative border-t border-slate-800/60 bg-[#060c18]"
      aria-label="Featured Projects"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-sky-950/70 border border-sky-500/30 text-xs font-mono text-sky-300 uppercase tracking-wider mb-3">
              <FolderGit2 className="w-3.5 h-3.5" />
              <span>Work &amp; Implementations</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
              Featured Projects
            </h2>
            <p className="mt-3 text-base text-slate-400 max-w-xl">
              Practical applications demonstrating software engineering principles, machine learning integration, and clean user experience.
            </p>
          </div>

          <div className="text-xs font-mono text-slate-400 bg-slate-900/60 px-4 py-2 rounded-lg border border-slate-800 self-start md:self-auto">
            <span>{projects.length} Featured Academic Projects</span>
          </div>
        </div>

        {/* Project Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project) => (
            <article
              key={project.id}
              className="group relative flex flex-col justify-between rounded-3xl bg-slate-900/70 border border-slate-800/90 hover:border-sky-500/50 transition-all duration-300 hover:shadow-2xl hover:shadow-sky-500/5 hover:-translate-y-1 overflow-hidden"
            >
              {/* Top Accent Line */}
              <div className="h-1 w-full bg-gradient-to-r from-sky-500/20 via-sky-400 to-blue-600/20 opacity-40 group-hover:opacity-100 transition-opacity" />

              <div className="p-7 sm:p-9 flex-1 flex flex-col">
                {/* Meta row */}
                <div className="flex items-center justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sky-400">
                      {getProjectIcon(project.id)}
                    </div>
                    <span className="text-xs font-mono font-medium text-sky-400 uppercase tracking-wider">
                      {project.statusBadge}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-slate-400">Student Project</span>
                </div>

                {/* Title & Subtitle */}
                <h3 className="text-xl sm:text-2xl font-bold text-slate-100 group-hover:text-sky-300 transition-colors mb-2">
                  {project.title}
                </h3>
                
                <p className="text-xs font-mono text-slate-400 mb-4">
                  {project.subtitle}
                </p>

                {/* Description */}
                <p className="text-sm text-slate-300 leading-relaxed mb-6">
                  {project.description}
                </p>

                {/* Key Bullet Highlights */}
                <div className="mb-6 pt-4 border-t border-slate-800/80">
                  <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
                    Core Functionality
                  </h4>
                  <ul className="space-y-2">
                    {project.highlights.slice(0, 3).map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-sky-400/90 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tech Stack Tags */}
                <div className="mt-auto pt-4 border-t border-slate-800/60">
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-2.5 py-1 rounded-md text-xs font-mono font-medium bg-slate-950/80 border border-slate-800 text-slate-300"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="px-7 sm:px-9 py-4 bg-slate-950/60 border-t border-slate-800 flex items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => setSelectedProject(project)}
                  className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-sky-400 hover:text-sky-300 transition-colors focus-visible:ring-2 focus-visible:ring-sky-400 rounded-md p-1"
                >
                  <span>Explore In-Depth</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <a
                  href="#contact"
                  className="text-xs text-slate-400 hover:text-slate-200 transition-colors"
                >
                  Ask question
                </a>
              </div>
            </article>
          ))}
        </div>

      </div>

      {/* Interactive Modal */}
      {selectedProject && (
        <ProjectModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
        />
      )}
    </section>
  );
}
