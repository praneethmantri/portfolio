import React from 'react';
import { 
  Code, 
  Layout, 
  Server, 
  Database, 
  Wrench, 
  Lightbulb, 
  Layers
} from 'lucide-react';
import { portfolioData } from '../data/portfolioData';

export default function Skills() {
  const { skillCategories } = portfolioData;

  const getCategoryIcon = (name) => {
    switch (name) {
      case 'Programming Languages':
        return <Code className="w-5 h-5 text-sky-400" />;
      case 'Frontend Development':
        return <Layout className="w-5 h-5 text-sky-400" />;
      case 'Backend Development':
        return <Server className="w-5 h-5 text-sky-400" />;
      case 'Databases':
        return <Database className="w-5 h-5 text-sky-400" />;
      case 'Developer Tools':
        return <Wrench className="w-5 h-5 text-sky-400" />;
      case 'Areas of Interest':
        return <Lightbulb className="w-5 h-5 text-amber-400" />;
      default:
        return <Layers className="w-5 h-5 text-sky-400" />;
    }
  };

  return (
    <section
      id="skills"
      className="py-20 sm:py-28 relative border-t border-slate-800/60 bg-[#070d1a]"
      aria-label="Technical Skills and Competencies"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col items-start mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-sky-950/70 border border-sky-500/30 text-xs font-mono text-sky-300 uppercase tracking-wider mb-3">
            <Layers className="w-3.5 h-3.5" />
            <span>Capabilities</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            Skills &amp; Technical Stack
          </h2>
          <p className="mt-3 text-base text-slate-400 max-w-2xl">
            A categorized overview of the languages, frameworks, developer tools, and computer science domains I work with.
          </p>
        </div>

        {/* Skill Category Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category) => (
            <div
              key={category.name}
              className="group p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-sky-500/40 transition-all duration-300 hover:shadow-xl hover:shadow-sky-500/5 hover:-translate-y-1 flex flex-col justify-between"
            >
              <div>
                {/* Header of Category Card */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2.5 rounded-xl bg-slate-800/90 border border-slate-700/60 group-hover:border-sky-500/40 transition-colors">
                    {getCategoryIcon(category.name)}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-100 group-hover:text-sky-300 transition-colors">
                      {category.name}
                    </h3>
                  </div>
                </div>

                <p className="text-xs text-slate-400 mb-5 leading-relaxed">
                  {category.description}
                </p>

                {/* Skills Badges / Pills (No percentage bars as required) */}
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill) => (
                    <span
                      key={skill}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-950/70 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors shadow-sm"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-sky-400/80" />
                      <span>{skill}</span>
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Subtle Indicator */}
              <div className="mt-6 pt-4 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>{category.skills.length} competencies</span>
                <span className="text-sky-400/70 group-hover:text-sky-300 transition-colors">verified</span>
              </div>
            </div>
          ))}
        </div>

        {/* Note on Learning */}
        <div className="mt-12 p-6 rounded-2xl bg-slate-900/40 border border-slate-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs sm:text-sm text-slate-400">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-sky-400 shrink-0" />
            <span>
              Always actively expanding my toolkit through academic coursework, open-source documentation, and hands-on project builds.
            </span>
          </div>
          <a
            href="#projects"
            className="text-sky-400 hover:text-sky-300 font-medium whitespace-nowrap shrink-0 hover:underline"
          >
            See skills in action &rarr;
          </a>
        </div>

      </div>
    </section>
  );
}
