import React from 'react';
import { GraduationCap, Compass, MapPin, CheckCircle2 } from 'lucide-react';
import { portfolioData } from '../data/portfolioData';

export default function About() {
  const { about, personal } = portfolioData;

  const keyStrengths = [
    "Clean, semantic web architecture and responsive interface design",
    "Solid foundations in Data Structures and algorithmic problem-solving",
    "Interest in integrating machine learning models into intuitive user applications",
    "Continuous learning mindset, curiosity, and attention to detail"
  ];

  return (
    <section
      id="about"
      className="py-20 sm:py-28 relative border-t border-slate-800/60 bg-[#060c18]"
      aria-label="About Mantri Praneeth"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="flex flex-col items-start mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-sky-950/70 border border-sky-500/30 text-xs font-mono text-sky-300 uppercase tracking-wider mb-3">
            <Compass className="w-3.5 h-3.5" />
            <span>Overview</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
            About Me
          </h2>
          <p className="mt-3 text-base text-slate-400 max-w-xl">
            A look into my background, technical focus, and aspirations as a Computer Science &amp; Engineering student.
          </p>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          
          {/* Main Narrative Column */}
          <div className="lg:col-span-7 space-y-6 text-slate-300 leading-relaxed text-base sm:text-lg">
            {about.bio.map((paragraph, index) => (
              <p key={index} className="text-slate-300 font-normal">
                {paragraph}
              </p>
            ))}

            {/* What I Focus On */}
            <div className="pt-6 mt-6 border-t border-slate-800/80">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-200 mb-4 font-mono">
                Key Technical Priorities
              </h3>
              <ul className="space-y-3">
                {keyStrengths.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm sm:text-base text-slate-300">
                    <CheckCircle2 className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Quick Facts / Info Cards Column */}
          <div className="lg:col-span-5 space-y-4">
            
            {about.highlights.map((item, index) => (
              <div
                key={index}
                className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-700/80 transition-all duration-200 hover:-translate-y-0.5"
              >
                <div className="text-xs font-mono font-medium text-sky-400 uppercase tracking-wider mb-1">
                  {item.label}
                </div>
                <div className="text-lg font-bold text-slate-100 mb-2">
                  {item.value}
                </div>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}

            {/* Location & Academic Badge */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-[#0b162c] border border-sky-500/20">
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-100">B.Tech in Computer Science</h4>
                  <p className="text-xs text-slate-400">Undergraduate Degree Program</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300 pt-3 border-t border-slate-800/80">
                <MapPin className="w-4 h-4 text-sky-400 shrink-0" />
                <span>{personal.location}</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
