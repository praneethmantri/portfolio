import { Mail, ArrowDown, FolderCode, Send, MapPin, Sparkles } from 'lucide-react';
import { LinkedinIcon } from './Icons';
import { portfolioData } from '../data/portfolioData';

export default function Hero() {
  const { personal } = portfolioData;

  const handleScrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 sm:py-28 lg:py-32 overflow-hidden"
      aria-label="Introduction and Hero"
    >
      {/* Subtle background glow effect (refined, not loud) */}
      <div 
        className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-sky-500/10 rounded-full blur-[120px] pointer-events-none" 
        aria-hidden="true" 
      />
      <div 
        className="absolute bottom-10 right-10 w-72 h-72 bg-blue-600/5 rounded-full blur-[100px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Hero Text & CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            
            {/* Status Pill */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-xs font-medium text-slate-300 shadow-sm mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>{personal.status}</span>
              <span className="text-slate-600">|</span>
              <span className="flex items-center gap-1 text-slate-400">
                <MapPin className="w-3 h-3 text-sky-400" />
                <span>Vizianagaram, India</span>
              </span>
            </div>

            {/* Main Headings */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight mb-4">
              Hi, I’m{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-sky-300 to-blue-400">
                {personal.name}
              </span>
              .
            </h1>

            <p className="text-xl sm:text-2xl font-semibold text-slate-300 mb-5 tracking-tight flex items-center gap-2">
              <span className="text-sky-400 font-mono font-normal">/&gt;</span>
              <span>{personal.subtitle}</span>
            </p>

            <p className="text-base sm:text-lg text-slate-400 max-w-2xl leading-relaxed mb-8">
              {personal.heroIntro}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 mb-10 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => handleScrollTo('projects')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold text-sm transition-all duration-200 shadow-lg shadow-sky-500/20 hover:shadow-sky-400/30 hover:-translate-y-0.5 focus-visible:ring-2 focus-visible:ring-sky-400"
              >
                <FolderCode className="w-4 h-4" />
                <span>View My Projects</span>
              </button>

              <button
                type="button"
                onClick={() => handleScrollTo('contact')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700/80 hover:border-slate-600 font-semibold text-sm transition-all duration-200 hover:-translate-y-0.5 focus-visible:ring-2 focus-visible:ring-sky-400"
              >
                <Send className="w-4 h-4 text-sky-400" />
                <span>Contact Me</span>
              </button>
            </div>

            {/* Social Links & Direct Email */}
            <div className="pt-6 border-t border-slate-800/80 w-full flex flex-wrap items-center gap-6 text-sm text-slate-400">
              <span className="text-xs uppercase tracking-wider font-semibold text-slate-400">
                Connect with me:
              </span>
              
              <div className="flex items-center gap-3">
                <a
                  href={personal.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-sky-500/50 hover:bg-slate-800/80 transition-all duration-200 group text-xs font-medium"
                  aria-label="Mantri Praneeth LinkedIn Profile"
                >
                  <LinkedinIcon className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
                  <span>LinkedIn</span>
                </a>

                <a
                  href={`mailto:${personal.email}`}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-sky-500/50 hover:bg-slate-800/80 transition-all duration-200 group text-xs font-medium"
                  aria-label={`Email ${personal.email}`}
                >
                  <Mail className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
                  <span>{personal.email}</span>
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: MP Monogram Card / Visual Showcase */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-sm sm:max-w-md">
              
              {/* Decorative subtle border frame */}
              <div className="relative p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 backdrop-blur-sm shadow-2xl shadow-black/40">
                
                {/* Header of Monogram Card */}
                <div className="flex items-center justify-between pb-5 mb-6 border-b border-slate-800/70">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500/70" />
                    <span className="w-3 h-3 rounded-full bg-amber-500/70" />
                    <span className="w-3 h-3 rounded-full bg-emerald-500/70" />
                  </div>
                  <span className="text-xs font-mono text-slate-400">developer.profile</span>
                </div>

                {/* Central MP Monogram Emblem */}
                <div className="flex flex-col items-center justify-center py-6 sm:py-8">
                  <div className="relative group">
                    {/* Monogram Outer Ring */}
                    <div className="w-36 h-36 sm:w-40 sm:h-40 rounded-2xl bg-gradient-to-br from-slate-950 via-[#0a1224] to-slate-900 p-1 border-2 border-sky-500/40 shadow-xl shadow-sky-500/10 flex items-center justify-center group-hover:border-sky-400 transition-colors">
                      <div className="w-full h-full rounded-xl bg-[#091122] flex flex-col items-center justify-center relative overflow-hidden">
                        
                        {/* Background pattern lines */}
                        <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:12px_12px] opacity-40" />

                        {/* Monogram Letters */}
                        <span className="relative z-10 text-5xl sm:text-6xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-br from-sky-300 via-sky-400 to-blue-500 select-none">
                          {personal.monogram}
                        </span>

                        <div className="relative z-10 mt-1 flex items-center gap-1 text-[10px] uppercase font-mono tracking-widest text-sky-400/80">
                          <span>Portfolio</span>
                        </div>
                      </div>
                    </div>

                    {/* Verified Student / Tech badge */}
                    <div className="absolute -bottom-2 -right-2 px-2.5 py-1 rounded-full bg-sky-950 border border-sky-400/60 shadow-lg text-[11px] font-semibold text-sky-300 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-sky-400" />
                      <span>CSE</span>
                    </div>
                  </div>

                  {/* Identification text underneath */}
                  <h2 className="mt-6 text-lg sm:text-xl font-bold text-slate-100 text-center">
                    {personal.name}
                  </h2>
                  <p className="text-xs text-sky-400/90 font-mono mt-1 text-center">
                    Computer Science &amp; Engineering
                  </p>
                  <p className="text-xs text-slate-400 text-center mt-2 flex items-center gap-1 justify-center">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>Andhra Pradesh, India</span>
                  </p>
                </div>

                {/* Quick Info Grid */}
                <div className="grid grid-cols-2 gap-3 pt-4 border-t border-slate-800/70 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                    <span className="text-slate-400 block mb-0.5 font-medium">Domain</span>
                    <span className="font-semibold text-slate-200">Web &amp; AI</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                    <span className="text-slate-400 block mb-0.5 font-medium">Primary Tech</span>
                    <span className="font-semibold text-slate-200">React • Python</span>
                  </div>
                </div>

              </div>

            </div>
          </div>

        </div>

        {/* Scroll down indicator */}
        <div className="hidden sm:flex justify-center mt-12">
          <button
            type="button"
            onClick={() => handleScrollTo('about')}
            className="flex flex-col items-center gap-2 text-xs text-slate-400 hover:text-sky-400 transition-colors focus:outline-none"
            aria-label="Scroll to About section"
          >
            <span className="font-mono text-[11px] uppercase tracking-wider">Explore</span>
            <ArrowDown className="w-4 h-4 animate-bounce text-sky-400" />
          </button>
        </div>

      </div>
    </section>
  );
}
