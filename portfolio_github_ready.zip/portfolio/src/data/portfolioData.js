export const portfolioData = {
  personal: {
    name: "Mantri Praneeth",
    shortName: "Praneeth",
    monogram: "MP",
    title: "CSE Student | Web Developer",
    subtitle: "CSE Student & Web Developer",
    heroIntro: "I enjoy building practical web applications and exploring how AI can solve real-world problems.",
    location: "Vizianagaram, Andhra Pradesh, India",
    email: "praneethmantri@gmail.com",
    linkedin: "https://www.linkedin.com/in/mantri-praneeth-55856034a",
    github: "https://github.com/praneethmantri",
    status: "Open to Internships & Projects",
    statusAvailable: true,
  },

  about: {
    bio: [
      "I am a Computer Science & Engineering student with a strong passion for designing and developing functional, user-centric web applications. My journey in tech centers around turning conceptual logic into clean, responsive software that solves genuine everyday problems.",
      "Beyond core full-stack web development, I am deeply curious about applied Artificial Intelligence and algorithmic problem solving. I continuously challenge myself to master core fundamentals in data structures, explore how machine learning models can be integrated into web products, and write well-structured, maintainable code.",
      "Based in Vizianagaram, Andhra Pradesh, I am eager to apply my technical foundations, learn from seasoned engineering teams, and contribute productively to internship opportunities."
    ],
    highlights: [
      {
        label: "Academic Focus",
        value: "Computer Science & Engineering",
        description: "Focusing on software development, algorithmic thinking, and modern web architectures."
      },
      {
        label: "Core Mindset",
        value: "Hands-on Engineering",
        description: "Building complete, working prototypes with attention to detail, reliability, and usability."
      },
      {
        label: "Current Endeavor",
        value: "Internship Seeking",
        description: "Ready to contribute strong fundamentals in web development and problem-solving to high-impact teams."
      }
    ]
  },

  skillCategories: [
    {
      name: "Programming Languages",
      description: "Foundational languages for problem-solving and application logic",
      skills: ["Python", "Java", "C", "JavaScript"]
    },
    {
      name: "Frontend Development",
      description: "Building responsive, modern, and accessible user interfaces",
      skills: ["HTML", "CSS", "React"]
    },
    {
      name: "Backend Development",
      description: "Designing server-side APIs, routing, and business logic",
      skills: ["Node.js", "Express"]
    },
    {
      name: "Databases",
      description: "Data modeling, relational queries, and document storage",
      skills: ["MySQL", "MongoDB"]
    },
    {
      name: "Developer Tools",
      description: "Version control, workflow efficiency, and environment management",
      skills: ["Git", "GitHub", "VS Code"]
    },
    {
      name: "Areas of Interest",
      description: "Emerging domains and foundational computer science pillars",
      skills: ["Machine Learning", "Quantum Computing", "Data Structures and Algorithms"]
    }
  ],

  projects: [
    {
      id: "ai-battery-health",
      title: "AI Battery Health Detection",
      subtitle: "Machine Learning & Battery Analytics",
      description: "A project focused on using battery usage and charging data to estimate battery health and support better charging decisions.",
      longDescription: "Lithium-ion batteries degrade over time based on charge cycles, operating temperature, and discharge patterns. This project analyzes operational parameters—including voltage curves, discharge durations, charging cycles, and temperature telemetry—to forecast State of Health (SoH). The system provides actionable insights to extend battery longevity and avoid premature degradation.",
      tags: ["Python", "Machine Learning", "Data Analysis", "Predictive Modeling", "Scikit-Learn"],
      highlights: [
        "Analyzes voltage, current, temperature, and cycle counts to detect degradation patterns",
        "Estimates battery State of Health (SoH) and remaining operational capacity",
        "Generates intelligent charging recommendations to prolong lifecycle and prevent thermal stress",
        "Demonstrates practical application of machine learning pipelines to hardware telemetry"
      ],
      featured: true,
      githubUrl: "https://github.com",
      statusBadge: "ML Project"
    },
    {
      id: "online-assessment-system",
      title: "Online Assessment System",
      subtitle: "Full-Stack Web Platform",
      description: "A secure, intuitive web platform engineered for conducting, evaluating, and managing online tests and quizzes with real-time feedback.",
      longDescription: "An end-to-end testing platform created to streamline remote examinations and automated student assessments. Features secure candidate authentication, timed assessment sessions with automatic question delivery, instantaneous evaluation upon submission, and an administrative dashboard for tracking performance metrics and score distributions.",
      tags: ["React", "Node.js", "Express", "Database", "REST APIs", "Tailwind CSS"],
      highlights: [
        "Interactive test-taking interface with countdown timer and seamless question navigation",
        "Automated grading engine delivering instant results and score breakdowns",
        "Secure user authentication and structured test management workflow",
        "Responsive, distraction-free UI optimized for both desktop and tablet screens"
      ],
      featured: true,
      githubUrl: "https://github.com",
      statusBadge: "Full-Stack Web"
    }
  ],

  navLinks: [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Skills", href: "#skills" },
    { name: "Projects", href: "#projects" },
    { name: "Contact", href: "#contact" }
  ]
};
